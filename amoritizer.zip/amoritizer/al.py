

loans = {}
def set_loans(loans):
    name = input("Name of loan\n")
    p = input("principal of loan\n")
    i = input("interest rate\n")
    min_pay = input("minimum payment\n")

    